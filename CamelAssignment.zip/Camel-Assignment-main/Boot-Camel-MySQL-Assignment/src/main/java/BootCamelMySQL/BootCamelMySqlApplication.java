package BootCamelMySQL;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootCamelMySqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootCamelMySqlApplication.class, args);
		System.out.println("Hi Ayush");
	}

}
