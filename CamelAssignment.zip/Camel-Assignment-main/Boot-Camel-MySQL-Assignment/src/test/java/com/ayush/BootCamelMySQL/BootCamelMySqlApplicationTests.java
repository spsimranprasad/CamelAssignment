package com.swati.BootCamelMySQL;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootCamelMySqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
